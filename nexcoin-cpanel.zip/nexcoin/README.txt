# Nexcoin — cPanel Deployment Guide

## Requirements
- Node.js 18+ (set in cPanel Node.js App)
- MySQL 5.7+ or MariaDB 10.3+

## Steps

### 1. Create MySQL Database
In cPanel > MySQL Databases, create a database and user with all privileges.

### 2. Import SQL Schema
In phpMyAdmin, select your database and run (import): nexcoin-setup.sql

### 3. Upload Files
Extract this zip and upload all contents to your application directory
(e.g. /home/youraccount/nexcoin/).

Directory structure after upload:
  nexcoin/
    app.js            <- startup file
    client/dist/      <- frontend assets
    public/uploads/   <- uploaded images (auto-created)
    uploads/plugins/  <- plugins (auto-created)
    nexcoin-setup.sql <- SQL (you can delete after import)
    README.txt        <- this file

### 4. Create Node.js Application in cPanel
- cPanel > Setup Node.js App > Create Application
- Node.js version: 18 (or 20)
- Application mode: Production
- Application root: /home/youraccount/nexcoin
- Application URL: your domain or subdomain
- Application startup file: app.js
- Click Create

### 5. Set Environment Variables (in the Node.js App settings)
Click "+" to add each variable:

  Variable Name    | Value
  -----------------|-----------------------------------------
  DATABASE_URL     | mysql://dbuser:dbpass@localhost:3306/dbname
  NODE_ENV         | production
  SESSION_SECRET   | (any 32+ character random string)

Example DATABASE_URL:
  mysql://nexcoin_user:MyPass123@localhost:3306/nexcoin_db

### 6. Start / Restart the Application
Click the Restart button in the Node.js App panel.

## Default Admin Credentials
  URL:      https://yourdomain.com/admin
  Username: admin
  Password: admin123456

IMPORTANT: Change the admin password immediately after first login!

## Troubleshooting

Problem: App shows "Internal Server Error"
Solution: Check the app log in cPanel Node.js App panel. Usually means
          DATABASE_URL is wrong or the SQL hasn't been imported.

Problem: Images not loading
Solution: Make sure public/uploads/ directory exists and is writable (chmod 755).

Problem: "Cannot connect to database"
Solution: Verify DATABASE_URL format. Use 127.0.0.1 instead of localhost if needed.
          Format: mysql://user:password@127.0.0.1:3306/database

Problem: Port error
Solution: Do NOT set the PORT variable — cPanel sets this automatically.
