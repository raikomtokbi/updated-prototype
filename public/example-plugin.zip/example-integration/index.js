export async function register(context) {
  const { app, hooks, pluginSlug, getConfig } = context;
  console.log('[' + pluginSlug + '] Plugin activated!');
  app.get('/api/plugins/' + pluginSlug + '/status', (req, res) => {
    const config = getConfig();
    res.json({ plugin: pluginSlug, status: 'active', environment: config.environment ?? 'sandbox' });
  });
  hooks.on('order:created', async (order) => {
    const config = getConfig();
    if (config.enable_logging) console.log('[' + pluginSlug + '] Order created');
  });
}